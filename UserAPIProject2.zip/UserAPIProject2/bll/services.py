from dal.database import SessionLocal
from dal import models
from datetime import date

class WarehouseService:
    """Бизнес-логика: операции с товарами и движением на складе"""

    def __init__(self):
        self.db = SessionLocal()

    def add_product(self, name, category, price, supplier_id):
        product = models.Product(name=name, category=category, price=price, supplier_id=supplier_id)
        self.db.add(product)
        self.db.commit()
        self.db.refresh(product)
        return product

    def record_operation(self, product_id, user_id, op_type, quantity):
        operation = models.WarehouseOperation(
            product_id=product_id,
            user_id=user_id,
            operation_type=op_type,
            quantity=quantity,
            date=date.today()
        )
        product = self.db.query(models.Product).get(product_id)
        if op_type.value == "приход":
            product.quantity += quantity
        else:
            product.quantity -= quantity

        self.db.add(operation)
        self.db.commit()
        self.db.refresh(operation)
        return operation

    def get_stock_report(self):
        return self.db.query(models.Product).all()
