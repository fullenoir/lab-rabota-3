from fastapi import APIRouter
from bll.services import WarehouseService
from dal.models import OperationType

router = APIRouter()
service = WarehouseService()

@router.get("/products")
def get_products():
    products = service.get_stock_report()
    return [{"id": p.id, "name": p.name, "qty": p.quantity, "price": p.price} for p in products]

@router.post("/add_product")
def add_product(name: str, category: str, price: float, supplier_id: int):
    return service.add_product(name, category, price, supplier_id)

@router.post("/operation")
def make_operation(product_id: int, user_id: int, op_type: str, quantity: int):
    op_type_enum = OperationType.INCOME if op_type == "приход" else OperationType.OUTCOME
    return service.record_operation(product_id, user_id, op_type_enum, quantity)
