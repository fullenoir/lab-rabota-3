from fastapi import FastAPI
from dal.database import Base, engine
from api.routes import router

# Создаем таблицы
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Warehouse Management System")
app.include_router(router)

# Для запуска: uvicorn main:app --reload
